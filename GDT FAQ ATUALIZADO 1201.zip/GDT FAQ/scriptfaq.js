document.addEventListener("DOMContentLoaded", () => {
    const perguntas = document.querySelectorAll(".pergunta");

    perguntas.forEach(pergunta => {
        pergunta.addEventListener("click", () => {
            const targetId = pergunta.getAttribute("data-target");
            const resposta = document.getElementById(targetId);

            // Alternar visibilidade e classe ativa
            if (pergunta.classList.contains("active")) {
                resposta.style.display = "none";
                pergunta.classList.remove("active");
            } else {
                // Fecha todas as outras respostas abertas
                document.querySelectorAll(".resposta").forEach(r => r.style.display = "none");
                document.querySelectorAll(".pergunta").forEach(p => p.classList.remove("active"));

                // Abre a resposta atual
                resposta.style.display = "block";
                pergunta.classList.add("active");
            }
        });
    });
});

document.addEventListener("DOMContentLoaded", () => {
    // Redireciona para a seção do formulário quando clicar em "Clique aqui"
    const redirectLink = document.getElementById('redirect');
    const formSection = document.getElementById('form-section');

    redirectLink.addEventListener("click", () => {
        formSection.style.display = "block";  // Exibe a seção de formulário
        window.scrollTo({
            top: formSection.offsetTop,
            behavior: 'smooth'
        });
    });

    // Função para esconder o prompt quando o usuário começa a digitar
    const questionInput = document.getElementById('question');

    questionInput.addEventListener("focus", () => {
        if (questionInput.placeholder === "Digite sua pergunta aqui...") {
            questionInput.placeholder = "";
        }
    });
});


document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("contact-form");

    form.addEventListener("submit", (e) => {
        e.preventDefault(); // Impede o envio do formulário para o servidor

        const email = document.getElementById("email").value;
        showPopup(`Obrigado por nos contactar! Em breve enviaremos um e-mail para o endereço de: ${email} com as informações necessárias para responder a sua pergunta.`);
    });

    // Função para mostrar o pop-up
    function showPopup(message) {
        // Cria os elementos do pop-up
        const overlay = document.createElement("div");
        overlay.className = "overlay";
        document.body.appendChild(overlay);

        const popup = document.createElement("div");
        popup.className = "popup";

        const popupMessage = document.createElement("p");
        popupMessage.textContent = message;

        const closeButton = document.createElement("button");
        closeButton.textContent = "Fechar";
        closeButton.addEventListener("click", () => {
            popup.remove();
            overlay.remove();
        });

        // Adiciona os elementos ao pop-up
        popup.appendChild(popupMessage);
        popup.appendChild(closeButton);
        document.body.appendChild(popup);

        // Mostra o pop-up e a overlay
        overlay.style.display = "block";
        popup.style.display = "block";
    }
});

